// helloWorld.cpp
// CSCI 1300 Fall 2022
// Author: Jake Joyner
// Recitation: 202 – Christopher Ebuka Ojukwu
// Homework 2 - Problem # 1
#include <iostream>
using namespace std;

int main(){
    cout << "Hello, world!" << endl;

    return 0;
}