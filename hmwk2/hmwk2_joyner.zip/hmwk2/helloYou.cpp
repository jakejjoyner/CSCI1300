// helloYou.cpp
// CSCI 1300 Fall 2022
// Author: Jake Joyner
// Recitation: 202 – Christopher Ebuka Ojukwu
// Homework 2 - Problem # 2
#include <iostream>
using namespace std;

main()
{
    cout << "Please enter your name below:"<< endl;
    string name;
    cin >> name;
    cout << "Hello, " << name << "!" << endl;
    return 0;
}